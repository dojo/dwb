dojo.provide("user_app.util.util");

dojo.require("dojo.cache");
dojo.require("dijit.form.Button");
dojo.require("dojox.form.BusyButton");

dojo.declare("user_app.util.util", null, {
  name: "Utility",

  sayName: function () {
    console.log(this.name);
  }
});
