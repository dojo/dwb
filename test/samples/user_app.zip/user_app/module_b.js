dojo.provide("user_app.module_b");

dojo.declare("user_app.module_b", null, {
  name: "Module B",

  sayName: function () {
    console.log(this.name);
  }
});
