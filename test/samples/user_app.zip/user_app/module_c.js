dojo.provide("user_app.module_c");

dojo.declare("user_app.module_c", null, {
  name: "Module C",

  sayName: function () {
    console.log(this.name);
  }
});
