dojo.provide("user_app.module_a");

dojo.declare("user_app.module_a", null, {
  name: "Module A",

  sayName: function () {
    console.log(this.name);
  }
});
